
const {people,age}=require('./people')
console.log(people,age);

const os=require('os')
console.log(os.platform(),os.homedir())